<?php
/**
 * @version   $Id: CssFileResolver.php 4532 2012-10-26 16:42:16Z btowles $
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2014 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

class Gantry_CssFileResolver extends Gantry_FileResolver
{
	protected $browser_checks = array();
	protected $platform_checks = array();


}
